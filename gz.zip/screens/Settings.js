import {

  StyleSheet,

} from "react-native";


const SettingsScreen = () => {


  return (

  );
};

const styles = StyleSheet.create({

});

export default SettingsScreen;
